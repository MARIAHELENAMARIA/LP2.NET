using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace Exercicio.Controllers;

public class ExercicioController : Controller{
    public string Index(){
        return "Método de ação Padrão.";
    }

    public string Saudacao01(string nome){
        return $"Olá {nome}, seja bem-vindo(a) ao IFSP.";
    }

    public string Saudacao02(string nome, int atv){
        return $"Olá {nome}, você deverá desenvolver {atv} atividade(s) ao longo do semestre.";
    }

    public string Saudacao03(string nome, string periodo){
        if(periodo == "Matutino"){
            return $"SEDCITEC - 18 a 22 de Setembro - Ola {nome}, como voce esta no periodo {periodo}, devera participar da SEDCITEC no periodo das 07:00 às 11:45";
        }
        else if(periodo == "Vespertino"){
            return $"SEDCITEC - 18 a 22 de Setembro - Ola {nome}, como voce esta no periodo {periodo}, devera participar da SEDCITEC no periodo das 13:15 às 18:00";
        }
        else{
            return "Período Inválido";
        }
    }
}